"""Reusable MongoDB CRUD operations for the AAC animal shelter collection."""

import logging
from collections.abc import Mapping

from bson.errors import InvalidDocument
from pymongo import MongoClient
from pymongo.errors import PyMongoError


LOGGER = logging.getLogger(__name__)


class AnimalShelter:
    """Authenticate to MongoDB and expose CRUD methods with simple results.

    Credentials are supplied by the caller rather than embedded in source code.
    Connection/authentication errors during construction propagate to the caller.
    CRUD errors are logged and return False, [], or 0, respectively.
    """

    def __init__(self, username, password, host="localhost", port=27017,
                 database="aac", collection="animals", auth_source="admin"):
        self.client = MongoClient(
            host=host, port=port, username=username, password=password,
            authSource=auth_source, serverSelectionTimeoutMS=5000,
        )
        self.database = self.client[database]
        self.collection = self.database[collection]
        try:
            # MongoClient connects lazily; ping surfaces connection errors now.
            self.client.admin.command("ping")
        except PyMongoError:
            self.client.close()
            raise

    def create(self, data):
        """Insert one nonempty document; return True on acknowledged success."""
        if not isinstance(data, Mapping) or not data:
            return False
        try:
            # Copy the document so PyMongo does not add _id to the caller's dict.
            return bool(self.collection.insert_one(dict(data)).acknowledged)
        except (PyMongoError, InvalidDocument, TypeError, ValueError):
            LOGGER.exception("Create failed")
            return False

    def read(self, query):
        """Return all matching documents as a list; {} reads all documents."""
        if not isinstance(query, Mapping):
            return []
        try:
            # Materialize the cursor here so iteration errors are handled here.
            return list(self.collection.find(dict(query)))
        except (PyMongoError, InvalidDocument, TypeError, ValueError):
            LOGGER.exception("Read failed")
            return []

    def update(self, query, changes):
        """Update matching documents; return the number actually modified.

        changes uses MongoDB operators, for example {"$set": {"name": "Max"}}.
        Empty filters are rejected to prevent accidental collection-wide writes.
        """
        if (not isinstance(query, Mapping) or not query
                or not isinstance(changes, Mapping) or not changes):
            return 0
        try:
            return self.collection.update_many(dict(query), dict(changes)).modified_count
        except (PyMongoError, InvalidDocument, TypeError, ValueError):
            LOGGER.exception("Update failed")
            return 0

    def delete(self, query):
        """Delete matching documents; return the count; reject empty filters."""
        if not isinstance(query, Mapping) or not query:
            return 0
        try:
            return self.collection.delete_many(dict(query)).deleted_count
        except (PyMongoError, InvalidDocument, TypeError, ValueError):
            LOGGER.exception("Delete failed")
            return 0

    def close(self):
        """Release the MongoDB client's connection resources."""
        self.client.close()


"""CS 340 Project Two dashboard by Jason Wick (jwick239526874).
AI assistance: OpenAI Codex supported implementation, debugging and documentation.
"""
import base64
import math
import os
import socket
from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, dash_table
from dash.dependencies import Input, Output
from jupyter_dash import JupyterDash
import dash_leaflet as dl
from CRUD_Python_Module import AnimalShelter

# MODEL: the existing Project One module owns all MongoDB access.
# The course requires this local training account at instantiation.
shelter = AnimalShelter("aacuser", "password")
FILTERS = {
    "water": {"animal_type": "Dog", "breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}, "sex_upon_outcome": "Intact Female", "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
    "mountain": {"animal_type": "Dog", "breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}, "sex_upon_outcome": "Intact Male", "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
    "disaster": {"animal_type": "Dog", "breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}, "sex_upon_outcome": "Intact Male", "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}},
    "reset": {},
}
LABELS = {"reset": "All shelter animals", "water": "Water Rescue", "mountain": "Mountain or Wilderness Rescue", "disaster": "Disaster or Individual Tracking"}

def retrieve(filter_name):
    """Query MongoDB through CRUD and normalize records for Dash JSON."""
    records = shelter.read(FILTERS[filter_name])
    if not records:
        return []
    frame = pd.DataFrame(records).drop(columns=["_id"], errors="ignore")
    frame = frame.astype(object).where(pd.notnull(frame), None)
    return frame.to_dict("records")

initial_data = retrieve("reset")
if not initial_data:
    raise RuntimeError("No shelter records returned; check aac.animals and authentication.")
preferred = ["animal_id", "name", "animal_type", "breed", "sex_upon_outcome", "age_upon_outcome_in_weeks", "outcome_type", "location_lat", "location_long"]
columns = [c for c in preferred if c in initial_data[0]]
box_name = os.getenv("CODIO_HOSTNAME", socket.gethostname()).split(".")[0]
preview_url = f"https://{box_name}-8053.codio.io"
standalone = os.getenv("DASH_STANDALONE") == "1"
app = Dash(__name__) if standalone else JupyterDash(__name__, server_url=preview_url)
logo = base64.b64encode(Path("Grazioso Salvare Logo.png").read_bytes()).decode()

# VIEW: branding and identity stay above every filtered dashboard state.
app.layout = html.Main([
    html.Header([
        html.A(html.Img(src="data:image/png;base64," + logo, style={"height": "82px"}, alt="Grazioso Salvare logo"), href="https://www.snhu.edu", target="_blank"),
        html.Div([html.H1("Grazioso Salvare", style={"margin": "0", "fontSize": "27px"}), html.Div("Search and Rescue Candidate Dashboard", style={"marginTop": "6px"})]),
        html.Div([html.Strong("jwick239526874"), html.Div("Jason Wick | CS 340 Project Two")], style={"marginLeft": "auto", "textAlign": "right"})
    ], style={"display": "flex", "alignItems": "center", "gap": "22px", "borderBottom": "2px solid #1d5366", "paddingBottom": "10px"}),
    html.H2("Choose a rescue profile", style={"fontSize": "18px", "margin": "14px 0 8px"}),
    dcc.RadioItems(id="rescue-filter", options=[{"label": "Water Rescue", "value": "water"}, {"label": "Mountain or Wilderness Rescue", "value": "mountain"}, {"label": "Disaster or Individual Tracking", "value": "disaster"}, {"label": "Reset", "value": "reset"}], value="reset", inline=True, inputStyle={"marginRight": "6px"}, labelStyle={"marginRight": "20px", "display": "inline-block", "paddingBottom": "8px"}),
    html.Div(id="result-status", role="status", style={"fontWeight": "bold", "margin": "8px 0"}),
    html.P("Select a row to locate an animal. Sort column headings or type beneath them to narrow the table.", style={"fontSize": "13px", "margin": "6px 0"}),
    dash_table.DataTable(id="animals-table", columns=[{"name": c.replace("_", " ").title(), "id": c} for c in columns], data=initial_data, row_selectable="single", selected_rows=[0], page_size=5, page_action="native", sort_action="native", sort_mode="multi", filter_action="native", style_table={"overflowX": "auto"}, style_cell={"fontFamily": "Arial", "fontSize": "12px", "textAlign": "left", "padding": "6px", "minWidth": "80px", "maxWidth": "180px", "whiteSpace": "normal", "height": "auto"}, style_header={"backgroundColor": "#1d5366", "color": "white", "fontWeight": "bold"}, style_data_conditional=[{"if": {"state": "selected"}, "backgroundColor": "#e1f0f5", "border": "1px solid #1d5366"}]),
    html.Div([
        html.Section([html.H2("Breed distribution", style={"fontSize": "18px"}), dcc.Graph(id="breed-chart", config={"displayModeBar": False}, style={"height": "330px"})], style={"width": "48%"}),
        html.Section([html.H2("Selected animal location", style={"fontSize": "18px"}), html.Div(id="animal-map")], style={"width": "50%"})
    ], style={"display": "flex", "justifyContent": "space-between", "gap": "20px"}),
    html.Footer("Austin Animal Center Outcomes | MongoDB and Dash | Jason Wick | jwick239526874", style={"fontSize": "12px", "marginTop": "10px"})
], style={"fontFamily": "Arial, sans-serif", "maxWidth": "1450px", "margin": "12px auto", "padding": "0 18px", "color": "#183440"})

# CONTROLLER: each rescue profile executes its own MongoDB query.
@app.callback(Output("animals-table", "data"), Output("animals-table", "selected_rows"), Output("animals-table", "page_current"), Output("animals-table", "filter_query"), Output("animals-table", "sort_by"), Output("result-status", "children"), Input("rescue-filter", "value"))
def update_table(profile):
    rows = retrieve(profile)
    return rows, ([0] if rows else []), 0, "", [], f"{LABELS[profile]} | {len(rows):,} matching records"

@app.callback(Output("breed-chart", "figure"), Input("animals-table", "derived_virtual_data"))
def update_chart(view_data):
    rows = initial_data if view_data is None else view_data
    if not rows:
        figure = px.pie(names=[], values=[])
        figure.add_annotation(text="No animals match the current filters", showarrow=False)
    else:
        counts = pd.Series([r.get("breed") or "Unknown" for r in rows]).value_counts()
        # Preserve the full total while keeping the unfiltered chart legible.
        if len(counts) > 8:
            counts = pd.concat([counts.head(8), pd.Series({"Other breeds": counts.iloc[8:].sum()})])
        figure = px.pie(names=counts.index, values=counts.values, hole=0.35)
        figure.update_traces(textinfo="percent", hovertemplate="%{label}: %{value} animals (%{percent})<extra></extra>")
    figure.update_layout(margin={"l": 8, "r": 8, "t": 8, "b": 8}, font={"family": "Arial", "size": 11}, legend={"font": {"size": 10}}, height=330)
    return figure

@app.callback(Output("animal-map", "children"), Input("animals-table", "derived_virtual_data"), Input("animals-table", "derived_virtual_selected_rows"))
def update_map(view_data, selected_rows):
    rows = initial_data if view_data is None else view_data
    if not rows:
        return html.P("No animals match the current filters.")
    index = selected_rows[0] if selected_rows else 0
    animal = rows[index if 0 <= index < len(rows) else 0]
    try:
        lat, lon = float(animal["location_lat"]), float(animal["location_long"])
        if not (math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError("Invalid coordinates")
    except (KeyError, TypeError, ValueError):
        return html.P("No valid location is available for this animal.")
    name = animal.get("name") or "Unnamed animal"
    detail = f"{animal.get('animal_id', '')} | {name} | {animal.get('breed', '')}"
    return [html.Div(detail, style={"fontSize": "12px", "marginBottom": "5px"}), dl.Map(center=[lat, lon], zoom=11, style={"width": "100%", "height": "305px"}, children=[dl.TileLayer(), dl.Marker(position=[lat, lon], children=[dl.Tooltip(detail), dl.Popup([html.Strong(name), html.P(animal.get("breed", ""))])])])]

if __name__ == "__main__":
    if standalone:
        app.run_server(host="0.0.0.0", port=8053, debug=False)
    else:
        app.run_server(mode="inline", host="0.0.0.0", port=8053, debug=False)

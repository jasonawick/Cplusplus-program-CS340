# Grazioso Salvare Project Two

Jason Wick | jwick239526874

Use the accompanying Word README for setup steps, screenshots, design rationale, test results and references.

Run ProjectTwoDashboard.ipynb from this directory in Jupyter using Run All. For a standalone preview run DASH_STANDALONE=1 python project_two_dashboard.py and open port 8053.

Requires MongoDB aac.animals, aacuser authentication against admin, and the course dataset. requirements.txt records installed dependency versions. The code uses the course training account at instantiation as required by the assignment.

AI assistance: OpenAI Codex supported code implementation, debugging, testing and documentation.
